//
//  InformationViewController.swift
//  project
//
//  Created by 于洋 on 16/1/6.
//  Copyright © 2016年 于洋. All rights reserved.
//

import UIKit

class InformationViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self .hideTopView(true)
    }
}
